package com.bobsusedbooks.enums;

public enum OfferStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CONVERTED_TO_BOOK
}

package com.bobsusedbooks.enums;

public enum ReferenceDataType {
    PUBLISHER,
    BOOK_TYPE,
    GENRE,
    CONDITION
}

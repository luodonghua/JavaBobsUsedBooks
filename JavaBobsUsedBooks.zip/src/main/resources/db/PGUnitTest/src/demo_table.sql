create table demo_table (id int primary key, name varchar(20));
insert into demo_table values (1,'test1'),(2,'test2');
